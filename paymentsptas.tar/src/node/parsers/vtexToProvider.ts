export const parseGiftCardToProvider = (giftCardRequest: GiftCardRequest) => {
  // Parse here the checkout request to the expected format
  return giftCardRequest
}

export const parseTransactionToProvider = (
  transactionRequest: TransactionRequest
) => {
  // Parse here the checkout request to the expected format
  return transactionRequest
}
