interface CreateSettlementBody {
  value: Float32Array
  requestId: string
}
